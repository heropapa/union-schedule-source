import { useState } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { toEmail } from '../../lib/supabase';
import './LoginPage.css';

export default function LoginPage() {
  const { login, loading, error } = useAuthStore();
  const [userId, setUserId] = useState('admin');
  const [password, setPassword] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!userId || !password) return;
    await login(toEmail(userId), password);
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <h1>업무 스케줄 관리</h1>
        <p className="login-subtitle">로그인하여 스케줄을 확인하세요</p>

        {error && <div className="login-error">{error}</div>}

        <div className="login-field">
          <label>아이디</label>
          <input
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="아이디 입력"
            autoComplete="username"
            autoFocus
          />
        </div>

        <div className="login-field">
          <label>비밀번호</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="사장님 전화번호 -없이"
            autoComplete="current-password"
          />
        </div>

        <button className="login-btn" type="submit" disabled={loading}>
          {loading ? '로그인 중...' : '로그인'}
        </button>
      </form>
    </div>
  );
}
