import { useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar/Sidebar';
import ScheduleCalendar from './components/Calendar/ScheduleCalendar';
import LoginPage from './components/Auth/LoginPage';
import { useAuthStore } from './store/useAuthStore';
import { useHistoryStore } from './store/useHistoryStore';
import './styles/global.css';

function App() {
  const { session, loading, initialize } = useAuthStore();
  const dataLoaded = useRef(false);

  useEffect(() => {
    initialize();
  }, [initialize]);

  // 로그인 후 클라우드 데이터 로드 (1회)
  useEffect(() => {
    if (!session || dataLoaded.current) return;
    dataLoaded.current = true;

    async function loadData() {
      const loaded = await useHistoryStore.getState().loadFromCloud();
      if (!loaded) {
        // 클라우드에 데이터 없으면 localStorage 폴백
        useHistoryStore.getState().load();
      }
    }
    loadData();
  }, [session]);

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', color: '#888' }}>
        로딩 중...
      </div>
    );
  }

  if (!session) {
    return <LoginPage />;
  }

  return (
    <div className="app-layout">
      <Sidebar />
      <main className="main-content">
        <ScheduleCalendar />
      </main>
    </div>
  );
}

export default App;
