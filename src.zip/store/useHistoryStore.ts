import { create } from 'zustand';
import type { Worker, Route, ScheduleCell, Camp } from '../types';
import { useWorkerStore } from './useWorkerStore';
import { useScheduleStore } from './useScheduleStore';
import { registerPushSnapshot, registerMarkDirty } from './historyBridge';
import { supabase } from '../lib/supabase';

interface OrderMap {
  sidebarRegular: string[];
  sidebarBackup: string[];
  tableRegular: string[];
  tableBackup: string[];
}

interface Snapshot {
  workers: Worker[];
  routes: Record<string, Route[]>;
  cells: Record<string, ScheduleCell>;
  orders?: Record<string, OrderMap>;
  camps?: Camp[];
}

const MAX_HISTORY = 50;
const STORAGE_KEY = 'schedule-saved-data';

interface HistoryState {
  past: Snapshot[];
  future: Snapshot[];
  dirty: boolean;
  cloudSynced: boolean;   // Supabase 동기화 상태
  cloudLoading: boolean;

  pushSnapshot: () => void;
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;
  save: () => void;
  load: () => void;
  saveToCloud: () => Promise<void>;
  loadFromCloud: () => Promise<boolean>;
}

function captureSnapshot(): Snapshot {
  const ws = useWorkerStore.getState();
  const ss = useScheduleStore.getState();
  return {
    workers: JSON.parse(JSON.stringify(ws.workers)),
    routes: JSON.parse(JSON.stringify(ws.routes)),
    cells: JSON.parse(JSON.stringify(ss.cells)),
    orders: JSON.parse(JSON.stringify(ws.orders)),
    camps: JSON.parse(JSON.stringify(ws.camps)),
  };
}

function restoreSnapshot(snap: Snapshot) {
  useWorkerStore.setState({
    workers: snap.workers,
    routes: snap.routes,
    ...(snap.orders ? { orders: snap.orders } : {}),
    ...(snap.camps ? { camps: snap.camps } : {}),
  });
  useScheduleStore.setState({ cells: snap.cells });
}

export const useHistoryStore = create<HistoryState>()((set, get) => ({
  past: [],
  future: [],
  dirty: false,
  cloudSynced: false,
  cloudLoading: false,

  pushSnapshot: () => {
    const snap = captureSnapshot();
    set((state) => ({
      past: [...state.past.slice(-(MAX_HISTORY - 1)), snap],
      future: [],
      dirty: true,
      cloudSynced: false,
    }));
  },

  undo: () => {
    const { past } = get();
    if (past.length === 0) return;
    const current = captureSnapshot();
    const prev = past[past.length - 1];
    restoreSnapshot(prev);
    set((state) => ({
      past: state.past.slice(0, -1),
      future: [current, ...state.future],
      dirty: true,
      cloudSynced: false,
    }));
  },

  redo: () => {
    const { future } = get();
    if (future.length === 0) return;
    const current = captureSnapshot();
    const next = future[0];
    restoreSnapshot(next);
    set((state) => ({
      past: [...state.past, current],
      future: state.future.slice(1),
      dirty: true,
      cloudSynced: false,
    }));
  },

  canUndo: () => get().past.length > 0,
  canRedo: () => get().future.length > 0,

  // localStorage 저장 (로컬 캐시)
  save: () => {
    const snap = captureSnapshot();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(snap));
      set({ dirty: false });
    } catch {
      // storage quota exceeded
    }
  },

  // localStorage 로드 (폴백)
  load: () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const snap: Snapshot = JSON.parse(raw);
      if (snap.workers && snap.routes && snap.cells) {
        restoreSnapshot(snap);
        set({ past: [], future: [], dirty: false });
      }
    } catch {
      // invalid data
    }
  },

  // Supabase에 저장
  saveToCloud: async () => {
    set({ cloudLoading: true });
    const snap = captureSnapshot();

    try {
      // 기존 current 해제
      await supabase
        .from('schedule_snapshots')
        .update({ is_current: false })
        .eq('is_current', true);

      // 새 스냅샷 저장
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from('schedule_snapshots')
        .insert({
          saved_by: user?.id,
          data: snap,
          is_current: true,
        });

      if (error) throw error;

      // localStorage에도 동시 저장
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(snap));
      } catch { /* ignore */ }

      set({ dirty: false, cloudSynced: true, cloudLoading: false });
    } catch (err) {
      console.error('Cloud save failed:', err);
      set({ cloudLoading: false });
    }
  },

  // Supabase에서 로드
  loadFromCloud: async () => {
    set({ cloudLoading: true });
    try {
      const { data, error } = await supabase
        .from('schedule_snapshots')
        .select('data')
        .eq('is_current', true)
        .single();

      if (error || !data) {
        set({ cloudLoading: false });
        return false;
      }

      const snap = data.data as Snapshot;
      if (snap.workers && snap.routes && snap.cells) {
        restoreSnapshot(snap);
        // localStorage에도 캐시
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(snap));
        } catch { /* ignore */ }
        set({ past: [], future: [], dirty: false, cloudSynced: true, cloudLoading: false });
        return true;
      }
      set({ cloudLoading: false });
      return false;
    } catch {
      set({ cloudLoading: false });
      return false;
    }
  },
}));

// Register bridge so stores can call pushHistory() without importing this file
registerPushSnapshot(() => useHistoryStore.getState().pushSnapshot());
registerMarkDirty(() => useHistoryStore.setState({ dirty: true }));
