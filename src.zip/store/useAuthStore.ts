import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Session, User } from '@supabase/supabase-js';

export type UserRole = 'admin' | 'viewer';

interface AuthState {
  session: Session | null;
  user: User | null;
  role: UserRole | null;
  loading: boolean;
  error: string | null;

  initialize: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: () => boolean;
}

export const useAuthStore = create<AuthState>()((set, get) => ({
  session: null,
  user: null,
  role: null,
  loading: true,
  error: null,

  initialize: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const role = await fetchRole(session.user.id);
        set({ session, user: session.user, role, loading: false, error: null });
      } else {
        set({ session: null, user: null, role: null, loading: false });
      }

      // 세션 변경 감지 (토큰 갱신, 로그아웃 등)
      supabase.auth.onAuthStateChange(async (_event, session) => {
        if (session?.user) {
          const role = await fetchRole(session.user.id);
          set({ session, user: session.user, role });
        } else {
          set({ session: null, user: null, role: null });
        }
      });
    } catch {
      set({ loading: false, error: '인증 초기화 실패' });
    }
  },

  login: async (email, password) => {
    set({ loading: true, error: null });
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      set({ loading: false, error: error.message });
      return;
    }
    if (data.user) {
      const role = await fetchRole(data.user.id);
      set({ session: data.session, user: data.user, role, loading: false });
    }
  },

  logout: async () => {
    await supabase.auth.signOut();
    set({ session: null, user: null, role: null, error: null });
  },

  isAdmin: () => get().role === 'admin',
}));

/** profiles 테이블에서 role 조회 */
async function fetchRole(userId: string): Promise<UserRole> {
  const { data } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', userId)
    .single();
  return (data?.role as UserRole) ?? 'viewer';
}
